package com.example.inventoryapplication.model;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class User {

    public String username;
    public String password;

}
